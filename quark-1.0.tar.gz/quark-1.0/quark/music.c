#include "music.h"
#include "main.h"
#include "playlist.h"

#include <gst/gconf/gconf.h>
#include <gst/gst.h>
#include <glib-2.0/glib.h>
#include <string.h>
#include <stdarg.h>

static GstElement *pipeline, *source, *decode, *sink, *queue, *thread;
gboolean playing = FALSE;

GList *notify_channels = NULL;

gboolean
music_flush (gpointer data)
{
    gst_bin_iterate (GST_BIN(data));
    return playing;
}

void 
music_eos (GstElement *element, gpointer data) 
{
    playlist_advance (1, main_loop_at_end);
}

/* This is the layout of our pipeline:
   { gnomevfssrc ! spider ! { queue ! volume ! osssink } }
 
   I copied it from the GstPlay library's hyperthreaded model.
 */
void
music_init ()
{
    pipeline = gst_pipeline_new ("pipe");
    g_assert (pipeline);

    thread = gst_thread_new ("thread");
    g_assert (thread);
    gst_bin_add (GST_BIN (pipeline), thread);

    queue = gst_element_factory_make ("queue", "queue");
    g_assert (queue);
    gst_bin_add (GST_BIN (thread), queue);

    // the gnomevfs plugin is broken
    if (!(source = gst_element_factory_make ("gnomevfssrc", "source"))) {
        g_warning ("unable to create gnome-vfs stream, using standard "
                   "file stream");
        if (!(source = gst_element_factory_make ("filesrc", "source"))) {
            g_critical ("unable to create source");
            exit (EXIT_FAILURE);
        }
    }
    gst_bin_add (GST_BIN (pipeline), source);

    if (!(sink = gst_gconf_get_default_audio_sink ())) {
        if (!(sink = gst_element_factory_make ("alsasink", "sink"))) {
            if (!(sink = gst_element_factory_make ("osssink", "sink"))) {
                g_critical ("unable to create output plugin");
                exit (EXIT_FAILURE);
            }
        }
    }
    gst_bin_add (GST_BIN (thread), sink);
    g_signal_connect (G_OBJECT (sink), "eos", G_CALLBACK (music_eos),
                      pipeline);

    gst_element_link (queue, sink);

    decode = NULL;
}


void
music_destroy ()
{
    gst_element_set_state (GST_ELEMENT (pipeline), GST_STATE_NULL);
    gst_object_unref (GST_OBJECT (pipeline));
}

void
music_play ()
{
    struct PlaylistItem *item;
    GstElementState state;

    state = gst_element_get_state(GST_ELEMENT(pipeline));

    if (state == GST_STATE_PAUSED) {
        music_pause ();
    } else if (state != GST_STATE_PLAYING && playlist_current) {
        item = LISTITEM (playlist_current);

        music_notify ("playing: %s", item->utf8_path);

        if (state != GST_STATE_READY)
            gst_element_set_state (GST_ELEMENT (pipeline), GST_STATE_READY);

        /* replace the spider */
        if (decode) {
            gst_element_unlink (decode, source);
            gst_element_unlink (decode, queue);
            gst_bin_remove (GST_BIN (pipeline), decode);
        }
        if (!(decode = gst_element_factory_make ("spider", "decoder"))) {
            g_critical ("unable to instantiate the spider plugin");
            exit (EXIT_FAILURE);
        }
        gst_bin_add (GST_BIN (pipeline), decode);
        gst_element_link (source, decode);
        gst_element_link (decode, queue);

        g_object_set (G_OBJECT (source), "location", item->path, NULL);

        if (gst_element_set_state (GST_ELEMENT (pipeline),
                                   GST_STATE_PLAYING) !=
            GST_STATE_FAILURE) {
            playing = TRUE;
            g_idle_add (music_flush, pipeline);
        } else {
            /* remove it from the playlist */
            playlist_remove (g_list_position (playlist, playlist_current));
        }
    }
}

void
music_pause ()
{
    GstElementState state = gst_element_get_state (GST_ELEMENT (pipeline));

    if (state == GST_STATE_PLAYING)
        gst_element_set_state (GST_ELEMENT (pipeline), GST_STATE_PAUSED);
    else if (state == GST_STATE_PAUSED)
        gst_element_set_state (GST_ELEMENT (pipeline), GST_STATE_PLAYING);
    else
        return;

    playing = !playing;
    if (playing) g_idle_add (music_flush, pipeline);
}

void
music_stop ()
{
    gst_element_set_state (GST_ELEMENT (pipeline), GST_STATE_READY);
    playing = FALSE;
}

void
music_add_notify (GIOChannel *output)
{
    notify_channels = g_list_prepend (notify_channels, output);
}

gboolean
music_list_notify (GIOChannel *channel, const char *message)
{
    gsize written;
    GIOStatus status;
    gboolean retval = FALSE;

    while ( (status = g_io_channel_write_chars (channel, message,
                                                strlen (message),
                                                &written, NULL))
            == G_IO_STATUS_AGAIN) {
        message += written;
    }
    
    if (status == G_IO_STATUS_ERROR) {
        retval = TRUE;
    }
    while ( (status = g_io_channel_flush(channel, NULL)) == G_IO_STATUS_AGAIN);

    if (status == G_IO_STATUS_ERROR)
        retval = TRUE;

    return retval;
}
    
void
music_notify (const char *format, ...)
{
    char *message, *newformat;
    GList *it;
    va_list args;

    va_start (args, format);
    
    message = g_strdup_vprintf(format, args);
    g_message ("%s", message);
    g_free (message);
            
    newformat = g_strdup_printf ("%s\n", format);
    message = g_strdup_vprintf (newformat, args);
    it = notify_channels;

    while (it != NULL) {
        if (music_list_notify (it->data, message)) {
            GList *tmp = it->next;
            g_list_remove_link (notify_channels, it);
            g_io_channel_shutdown (it->data, FALSE, NULL);
            g_io_channel_unref (it->data);
            if (it == notify_channels) {
                notify_channels = NULL;
            }
            it = tmp;
        } else {
            it = it->next;
        }
    }
    g_free (message);
    g_free (newformat);
    
    va_end (args);
}
