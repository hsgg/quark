#include "fifo.h"
#include "music.h"
#include "playlist.h"
#include "main.h"

#include <glib.h>
#include <gconf/gconf-client.h>
#include <gst/gst.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <signal.h>
#include <string.h>

gboolean    main_loop_at_end;  /* loop at the end of the playlist */
gboolean    main_random_order; /* play tracks in random order */
gboolean    main_play_on_run;  /* start playing when quark first runs */
QuarkStatus main_status;

static GMainLoop *loop;

#define QUARK_GCONF_ROOT "/apps/quark"
#define QUARK_GCONF_ROOT_PLAYLIST "/apps/quark/playlist"
#define LOOP_PLAYLIST QUARK_GCONF_ROOT "/loop_playlist"
#define RANDOM_ORDER  QUARK_GCONF_ROOT "/random_order"
#define PLAY_ON_RUN  QUARK_GCONF_ROOT "/play_at_startup"
#define PLAYLIST_POSITION QUARK_GCONF_ROOT_PLAYLIST "/position"
#define PLAYLIST QUARK_GCONF_ROOT_PLAYLIST "/playlist"

static void config_load    (GConfClient *gconf);
static void config_save    (GConfClient *gconf);
static void config_changed (GConfClient *gconf,
                            guint cnxn_id,
                            GConfEntry *entry,
                            gpointer data);
void
signal_handler (int signal)
{
    switch (signal) {
    case SIGTERM:
    case SIGINT:
        main_quit ();
        break;
    case SIGHUP:
        playlist_clear ();
        break;
    }
}

int
main (int argc, char **argv)
{
    GConfClient *gconf;
    char *dir;
    struct sigaction action;
    sigset_t sigset;

    main_status = QUARK_STARTING;

    /* set up signal handler */
    sigemptyset (&sigset);
    action.sa_handler = signal_handler;
    action.sa_mask = sigset;
    action.sa_flags = SA_NOCLDSTOP;
    sigaction (SIGTERM, &action, (struct sigaction *) NULL);
    sigaction (SIGINT, &action, (struct sigaction *) NULL);
    sigaction (SIGHUP, &action, (struct sigaction *) NULL);

    gconf = gconf_client_get_default ();
    gconf_client_add_dir (gconf, QUARK_GCONF_ROOT,
                          GCONF_CLIENT_PRELOAD_RECURSIVE, NULL);
    gconf_client_notify_add (gconf, QUARK_GCONF_ROOT, config_changed, NULL,
                             NULL, NULL);

    /* make the directory we use in ~ */
    dir = g_build_filename (g_get_home_dir(), ".quark", NULL);
    mkdir (dir, S_IRWXU|S_IRWXG|S_IRWXO);
    g_free (dir);

    loop = g_main_loop_new (NULL, FALSE);

    gst_init (&argc, &argv);

    if (!fifo_open ()) {
        g_critical("failed to open fifo");
        return 1;
    }

    music_init ();
    playlist_init ();

    config_load (gconf);

    main_status = QUARK_RUNNING;

    if (main_play_on_run) music_play ();

    g_main_loop_run (loop);
    main_status = QUARK_EXITING;

    config_save (gconf);

    playlist_destroy ();
    music_destroy ();

    fifo_destroy ();
    g_main_loop_unref (loop);
    g_object_unref (G_OBJECT (gconf));

    return 0;
}

void
main_quit ()
{
    g_main_loop_quit (loop);
}

static void
config_load (GConfClient *gconf)
{
    GConfValue *val;
    GSList *paths, *it;

    val = gconf_client_get (gconf, PLAY_ON_RUN, NULL);
    if (val && val->type == GCONF_VALUE_BOOL)
        main_play_on_run = gconf_value_get_bool (val);
    else
        main_play_on_run = FALSE;
    if (val) gconf_value_free(val);

    val = gconf_client_get (gconf, LOOP_PLAYLIST, NULL);
    if (val && val->type == GCONF_VALUE_BOOL)
        main_set_loop_at_end (gconf_value_get_bool (val));
    else
        main_set_loop_at_end (FALSE);
    if (val) gconf_value_free(val);

    val = gconf_client_get (gconf, RANDOM_ORDER, NULL);
    if (val && val->type == GCONF_VALUE_BOOL)
        main_set_random_order (gconf_value_get_bool (val));
    else
        main_set_random_order (FALSE);
    if (val) gconf_value_free(val);

    paths = gconf_client_get_list (gconf, PLAYLIST, GCONF_VALUE_STRING, NULL);
    for (it = paths; it; it = g_slist_next (it)) {
        GError *e = NULL;
        gchar *p = g_filename_from_utf8 (it->data, -1, NULL, NULL, &e);
        if (p) { playlist_append (p); g_free(p); }
        if (e) {
            g_warning ("Error loading playlist: %s", e->message);
            g_error_free(e);
        }
        g_free(it->data);
    }
    g_slist_free(paths);

    /* don't need another copy of the playlist in memory, and
       gconf_client_clear_cache makes a nice segfault when I try save stuff
       later. This value can't be edited while quark is running anyways.
    */
    gconf_client_unset (gconf, PLAYLIST, NULL);

    val = gconf_client_get (gconf, PLAYLIST_POSITION, NULL);
    if (val && val->type == GCONF_VALUE_INT)
        playlist_seek (gconf_value_get_int (val));
    if (val) gconf_value_free(val);
}

static void
config_save (GConfClient *gconf)
{
    GList *it;
    GSList *paths = NULL;

    gconf_client_set_bool (gconf, PLAY_ON_RUN, main_play_on_run, NULL);
    gconf_client_set_bool (gconf, LOOP_PLAYLIST, main_loop_at_end, NULL);
    gconf_client_set_bool (gconf, RANDOM_ORDER, main_random_order, NULL);
    gconf_client_set_int (gconf, PLAYLIST_POSITION,
                          g_list_position (playlist, playlist_current), NULL);

    for (it = playlist; it; it = g_list_next(it)) {
        paths = g_slist_append (paths,
                                ((struct PlaylistItem *)it->data)->utf8_path);
    }
    gconf_client_set_list (gconf, PLAYLIST, GCONF_VALUE_STRING,
                           paths, NULL);
    g_slist_free(paths);

    gconf_client_suggest_sync (gconf, NULL);
}

static void
config_changed (GConfClient *gconf,
                guint cnxn_id,
                GConfEntry *entry,
                gpointer data)
{
    if (!strcmp (entry->key, LOOP_PLAYLIST)) {
        if (entry->value->type == GCONF_VALUE_BOOL)
            main_set_loop_at_end (gconf_value_get_bool (entry->value));
    } else if (!strcmp (entry->key, RANDOM_ORDER)) {
        if (entry->value->type == GCONF_VALUE_BOOL)
            main_set_random_order (gconf_value_get_bool (entry->value));
    }
}

void
main_set_loop_at_end (gboolean loop)
{
    main_loop_at_end = loop;
    g_message ("looping at end of playlist: %s",
               main_loop_at_end ? "On" : "Off");
}

void
main_set_random_order (gboolean random)
{
    main_random_order = random;
    g_message ("random order playback: %s",
               main_random_order ? "On" : "Off");
}
