#ifndef __playlist_h
#define __playlist_h

#include <gst/gst.h>

extern GList *playlist;
extern GList *playlist_current;

struct PlaylistItem {
    char *path;
    char *utf8_path;
};

#define LISTITEM(it) ((struct PlaylistItem*)(it->data))

void playlist_init    ();
void playlist_destroy ();
void playlist_append  (const char *path);
void playlist_advance (int num, gboolean loop);
void playlist_seek    (int num);
void playlist_clear   ();
void playlist_remove  (int num);
/* before = -1 to move to the end of the list */
void playlist_move    (int num, int before);
void playlist_dump    ();

#endif
