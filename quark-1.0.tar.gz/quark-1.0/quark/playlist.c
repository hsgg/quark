#include "playlist.h"
#include "music.h"
#include "main.h"

GList *playlist = NULL;
GList *playlist_current = NULL;

static GList *playlist_random = NULL;

void
playlist_init ()
{
}

void
playlist_destroy ()
{
    playlist_clear ();
}

struct PlaylistItem *listitem_new(const char *path)
{
    struct PlaylistItem *s;
    GError *e = NULL;
    char *p;

    if (!(p = g_filename_to_utf8 (path, -1, NULL, NULL, &e))) {
        g_warning ("converting '%s' to UTF-8 failed", path);
        p = g_strdup ("Unknown");
    }

    s = g_new (struct PlaylistItem, 1);
    s->path = g_strdup (path);
    s->utf8_path = p;
    return s;
}

void listitem_free (struct PlaylistItem *item)
{
    g_free (item->utf8_path);
    g_free (item->path);
    g_free (item);
}

void
playlist_append (const char *path)
{
    struct PlaylistItem *item = listitem_new(path);
    int p;

    if (item) {
        music_notify ("appending %s", item->utf8_path);
        playlist = g_list_append (playlist, item);

        if (!playlist_current) playlist_current = playlist;

        p = g_list_position (playlist_random,
                             g_list_find (playlist_random,
                                          playlist_current->data));
        playlist_random = g_list_insert
            (playlist_random, item, 
             g_random_int_range (p, g_list_length (playlist)) + 1);
    }
}

void
playlist_advance (int num, gboolean loop)
{
    static GList *rand_cur = NULL;
    gboolean looped;

    music_notify ("advancing %d track(s)", num);
    
    rand_cur = g_list_find (playlist_random, playlist_current->data);

    if (main_random_order) {
        while (rand_cur && num > 0) {
            rand_cur = rand_cur->next;
            if (!rand_cur) {
                /* XXX re-randomize the whole thing */
                rand_cur = playlist_random;
                looped = TRUE;
            }
            --num;
        }
        while (rand_cur && num < 0) {
            rand_cur = rand_cur->prev;
            if (!rand_cur) {
                /* XXX re-randomize the whole thing */
                rand_cur = g_list_last (playlist_random);
                looped = TRUE;
            }
            ++num;
        }
        playlist_current = g_list_find (playlist_random,
                                        rand_cur->data);
    } else {
        while (playlist_current && num > 0) {
            playlist_current = playlist_current->next;
            if (!playlist_current) {
                playlist_current = playlist;
                looped = TRUE;
            }
            --num;
        }
        while (playlist_current && num < 0) {
            playlist_current = playlist_current->prev;
            if (!playlist_current) {
                playlist_current = g_list_last (playlist);
                looped = TRUE;
            }
            ++num;
        }
    }
    music_stop ();
    if (!looped || loop)
        music_play ();
}

void
playlist_seek (int num)
{
    GList *it = g_list_nth (playlist, num);

    if (it) {
        music_notify ("seeking to track %d", num);
        
        playlist_current = it;
        /* this function is used during load, and we don't want to start
           playing necessarily */
        if (main_status == QUARK_RUNNING) {
            music_stop ();
            music_play ();
        }
    }
}

void
playlist_clear ()
{
    music_notify ("clearing playlist");
    
    while (playlist) {
        listitem_free (playlist->data);
        playlist = g_list_delete_link (playlist, playlist);
    }
    playlist = playlist_current = NULL;
    g_list_free (playlist_random);
    playlist_random = NULL;
    music_stop ();
}

void
playlist_remove (int num)
{
    GList *it = g_list_nth (playlist, num);

    if (it) {
        music_notify ("removing track %d", num);
        
        if (it == playlist_current)
            playlist_advance (1, main_loop_at_end);
        if (it == playlist_current) {
            music_stop ();
            playlist_current = NULL;
        }

        listitem_free (it->data);
        playlist = g_list_delete_link (playlist, it);
    }
}

void
playlist_move (int num, int before)
{
    GList *it = g_list_nth (playlist, num);
    struct PlaylistItem *item;

    if (!it || num == before || num == before + 1) return;

    music_notify ("moving track %d before track %d", num, before);
    
    item = it->data;
    playlist = g_list_insert_before (playlist, g_list_nth (playlist, before),
                                     item);
    playlist = g_list_delete_link(playlist, it);
    /* XXX reinsert in the random order list? */
}

void
playlist_dump ()
{
    GList *it;
    int i = 0;

    music_notify ("Current playlist:");

    for (it = playlist; it; it = g_list_next(it)) {
        char *base = g_path_get_basename
            (((struct PlaylistItem*)it->data)->path);
        g_print ("%s %d %s\n",
                 (it->data == playlist_current->data ? ">" : " "), i++, base);
        g_free (base);
    }
}
