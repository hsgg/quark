#ifndef __music_h
#define __music_h

#include <glib.h>

#ifndef G_GNUC_PRINTF
#  define G_GNUC_PRINTF()
#endif

void music_init       ();
void music_destroy    ();
void music_play       ();
void music_pause      ();
void music_stop       ();
/* this should probably go in some other namespace... */
void music_add_notify (GIOChannel *output);
void music_notify     (const char *format, ...) G_GNUC_PRINTF (1, 2);

#endif
