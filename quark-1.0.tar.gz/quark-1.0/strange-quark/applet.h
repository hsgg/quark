#ifndef __applet_h
#define __applet_h

void applet_startup ();
void applet_shutdown ();

#endif
