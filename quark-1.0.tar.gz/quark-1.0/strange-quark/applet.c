#include "config.h"

#include "trayicon.h"

GtkWidget *trayicon;
GtkWidget *menu;

gboolean
menu_quit(GtkWidget *item, gpointer data)
{
    gtk_main_quit();
    return FALSE;
}

void applet_startup ()
{
    GtkWidget *item;

    menu = gtk_menu_new();

    item = gtk_menu_item_new_with_mnemonic ("_Play");
    gtk_menu_shell_append (GTK_MENU_SHELL (menu), item);

    item = gtk_menu_item_new_with_mnemonic ("P_ause");
    gtk_menu_shell_append (GTK_MENU_SHELL (menu), item);

    item = gtk_menu_item_new_with_mnemonic ("_Stop");
    gtk_menu_shell_append (GTK_MENU_SHELL (menu), item);

    item = gtk_image_menu_item_new_from_stock(GTK_STOCK_QUIT, NULL);
    gtk_menu_shell_append (GTK_MENU_SHELL (menu), item);
    g_signal_connect(item, "activate", G_CALLBACK(menu_quit), NULL);

    gtk_widget_show_all (GTK_WIDGET (menu));

    trayicon = trayicon_new ();

    trayicon_set_name (TRAYICON (trayicon), "strange-quark");
    trayicon_set_menu (TRAYICON (trayicon), menu);

    trayicon_show (TRAYICON (trayicon));
}

void applet_shutdown ()
{
    gtk_object_destroy (GTK_OBJECT (trayicon));
}










/*
static GtkWidget *applet = NULL;

static Atom tray_atom;

#define SYSTEM_TRAY_REQUEST_DOCK    0
#define SYSTEM_TRAY_BEGIN_MESSAGE   1
#define SYSTEM_TRAY_CANCEL_MESSAGE  2

static void
applet_embed (GdkNativeWindow socket_id);

static GdkFilterReturn
applet_manager_filter (GdkXEvent *xevent,
                       GdkEvent *event,
                       gpointer data)
{
    XEvent *e = (XEvent*) xevent;
    static glong last_time = 0;

    if ((Atom)e->xclient.data.l[1] == tray_atom) {
        if (e->xclient.data.l[0] > last_time) {
            last_time = e->xclient.data.l[0];
            applet_embed ((GdkNativeWindow) e->xclient.data.l[2]);
        }
        return GDK_FILTER_REMOVE;
    }
    return GDK_FILTER_CONTINUE;
}

void
applet_startup ()
{
    gchar *tray_sel;
    Window tray;

    tray_sel = g_strdup_printf ("_NET_SYSTEM_TRAY_S%d",
                                gdk_screen_get_number
                                (gdk_screen_get_default ()));
    tray_atom = gdk_x11_get_xatom_by_name (tray_sel);
    g_free (tray_sel);
    
    gdk_add_client_message_filter (gdk_atom_intern ("MANAGER", FALSE),
                                   applet_manager_filter, NULL);

    /\* if the selection exists, we use it, otherwise we'll just hang around
       and wait for the MANAGER client message (applet_manager_filter catches
       them *\/
    if ((tray = XGetSelectionOwner (GDK_DISPLAY_XDISPLAY
                                    (gdk_display_get_default ()),
                                    tray_atom))) {
        applet_embed (tray);
    }
}

void
applet_shutdown ()
{
    if (applet) {
        gtk_widget_destroy(applet);
        applet = NULL;
    }
}

/\*
static void
applet_destroy_event(GtkWidget *applet,
                     GdkEvent *event,
                     gpointer user_data)
{
    if (applet) {
        g_object_unref (G_OBJECT (applet));
        applet = NULL;
    }
    g_message("destroy event");
}
*\/

static void
applet_embed (GdkNativeWindow tray)
{
    GtkWidget *label;
    GdkWindow *tray_window;
    GdkEvent *dock_event;

    g_print ("embedding\n");

    if (applet) {
        gtk_widget_destroy(applet);
        applet = NULL;
    }

    tray_window = gdk_window_foreign_new (tray);

    dock_event = gdk_event_new (GDK_CLIENT_EVENT);
    dock_event->client.window = tray_window;
    dock_event->client.send_event = TRUE;
    dock_event->client.message_type =
        gdk_atom_intern ("_NET_SYSTEM_TRAY_OPCODE", FALSE);
    dock_event->client.data_format = 32;
    dock_event->client.data.l[0] = GDK_CURRENT_TIME;
    dock_event->client.data.l[1] = SYSTEM_TRAY_REQUEST_DOCK;
    dock_event->client.data.l[2] = GDK_WINDOW_XID (GDK_WINDOW (applet));
    dock_event->client.data.l[3] = 0;
    dock_event->client.data.l[4] = 0;
    gdk_event_send_client_message (dock_event, tray);

    g_object_unref (G_OBJECT (tray_window));
                                                      
    applet = gtk_plug_new(tray);

    label = gtk_label_new ("SQ");
    gtk_container_add (GTK_CONTAINER (applet), label);

    gtk_widget_show_all (GTK_WIDGET (applet));
}
*/
