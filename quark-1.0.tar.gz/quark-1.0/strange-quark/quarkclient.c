#include "config.h"

#include "quarkclient.h"

#include <sys/types.h> /* for getpid() */
#include <unistd.h>    

#include <errno.h>     /* for open()/close()/stat()/strerror() */
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

enum {
    CLOSED,
    PLAYLIST_CHANGED,
    PLAYLIST_POSITION_CHANGED,
    QUARKCLIENT_NUM_SIGNALS
};

static guint quarkclient_signals[QUARKCLIENT_NUM_SIGNALS] = { 0 };

static void     quarkclient_class_init (QuarkClientClass *klass);
static void     quarkclient_init       (QuarkClient *ti);
static void     quarkclient_finalize   (GObject *object);
static gboolean quarkclient_event      (GIOChannel *source,
                                        GIOCondition cond,
                                        gpointer data);

GType
quarkclient_get_type ()
{
    static GType type = 0;
    if (!type) { /* cache it */
        static const GTypeInfo info = {
            sizeof(QuarkClientClass),
            NULL, /* base_init */
            NULL, /* base_finalize */
            (GClassInitFunc) quarkclient_class_init,
            NULL, /* class_finalize */ 
            NULL, /* class_data */
            sizeof(QuarkClient),
            0, /* n_preallocs */
            (GInstanceInitFunc) quarkclient_init,
        };
        type = g_type_register_static (G_TYPE_OBJECT, "QuarkClient", &info, 0);
    }
    return type;
}

static void
quarkclient_class_init (QuarkClientClass *klass)
{
    GObjectClass *gobject_class = G_OBJECT_CLASS (klass);

    quarkclient_signals[CLOSED] =
        g_signal_new ("closed", G_TYPE_FROM_CLASS(klass),
                      G_SIGNAL_RUN_FIRST,
                      G_STRUCT_OFFSET (QuarkClientClass, closed),
                      NULL, NULL,
                      g_cclosure_marshal_VOID__VOID,
                      G_TYPE_NONE,
                      0);
    quarkclient_signals[PLAYLIST_CHANGED] =
        g_signal_new ("playlist-changed", G_TYPE_FROM_CLASS(klass),
                      G_SIGNAL_RUN_FIRST,
                      G_STRUCT_OFFSET (QuarkClientClass, playlist_changed),
                      NULL, NULL,
                      g_cclosure_marshal_VOID__VOID,
                      G_TYPE_NONE,
                      0);
    quarkclient_signals[PLAYLIST_POSITION_CHANGED] =
        g_signal_new ("playlist-position-changed", G_TYPE_FROM_CLASS(klass),
                      G_SIGNAL_RUN_FIRST,
                      G_STRUCT_OFFSET (QuarkClientClass,
                                       playlist_position_changed),
                      NULL, NULL,
                      g_cclosure_marshal_VOID__VOID,
                      G_TYPE_NONE,
                      0);

    gobject_class->finalize = quarkclient_finalize;
}

static void
quarkclient_init (QuarkClient *qc)
{
    gchar *pidname;
    qc->output_path = g_build_filename (g_get_home_dir(), ".quark",
                                        "fifo", NULL);
    pidname = g_strdup_printf("strange.%u", getpid());
    qc->input_path = g_build_filename (g_get_home_dir(), ".quark",
                                       pidname, NULL);
    g_free(pidname);

    qc->input = qc->output = NULL;
}

static void
quarkclient_finalize (GObject *object)
{
    QuarkClient *qc = QUARKCLIENT (object);
    if (qc->input) g_io_channel_unref (qc->input);
    if (qc->output) g_io_channel_unref (qc->output);
    g_free(qc->input_path);
    g_free(qc->output_path);
}

QuarkClient *
quarkclient_new()
{
    return g_object_new (QUARKCLIENT_TYPE, NULL);
}

static GIOChannel *
open_fifo (const gchar *path, int mode, GError **error)
{
    int fd;
    struct stat statbuf;
    GIOChannel *chan;

    fd = open (path,
               O_RDONLY | O_CREAT | O_NONBLOCK,
               S_IRWXU | S_IRWXG | S_IRWXO);
    if (fd < 0) {
        if (error)
            *error = g_error_new_literal (G_IO_CHANNEL_ERROR,
                                          g_io_channel_error_from_errno(errno),
                                          strerror(errno));
        return NULL;
    }

    if (fstat(fd, &statbuf) < 0) {
        if (error)
            *error = g_error_new_literal (G_IO_CHANNEL_ERROR,
                                          g_io_channel_error_from_errno(errno),
                                          strerror(errno));
        close (fd);
        return NULL;
    }

    if (!S_ISFIFO(statbuf.st_mode)) {
        if (error)
            *error = g_error_new(G_IO_CHANNEL_ERROR, G_IO_CHANNEL_ERROR_PIPE,
                                 "%s is not a FIFO", path);
        close (fd);
        return NULL;
    }

    chan = g_io_channel_unix_new (fd);
    g_io_channel_set_close_on_unref (chan, TRUE);

    return chan;
}

gboolean
quarkclient_open (QuarkClient *qc, GError **error)
{
    if (qc->input && qc->output) return TRUE;

    qc->output = open_fifo (qc->output_path, O_WRONLY | O_NONBLOCK, error);
    if (!qc->output) return FALSE;
    g_io_add_watch (qc->output, G_IO_HUP, quarkclient_event, qc);

    qc->input = open_fifo (qc->input_path,
                           O_RDONLY | O_CREAT | O_NONBLOCK, error);
    if (!qc->input) {
        quarkclient_close(qc);
        return FALSE;
    }
    g_io_add_watch (qc->input, G_IO_HUP | G_IO_IN, quarkclient_event, qc);

    return TRUE;
}

void
quarkclient_close (QuarkClient *qc)
{
    gboolean wasopen = qc->input && qc->output;

    if (qc->input) {
        g_io_channel_unref (qc->input);
        qc->input = NULL;
        unlink (qc->input_path);
    }
    if (qc->output) {
        g_io_channel_unref (qc->output);
        qc->output = NULL;
    }

    if (wasopen)
        g_signal_emit (qc, quarkclient_signals[CLOSED], 0);
}

static gboolean
quarkclient_event (GIOChannel *source, GIOCondition cond, gpointer data)
{
    QuarkClient *qc = QUARKCLIENT (data);

    if (source == qc->input && cond & G_IO_IN) {
        /* XXX read it! fire those signals! g_signal_emit ()! */
    }
    if (cond & G_IO_HUP) {
        quarkclient_close (qc);
        return FALSE;
    }
    return TRUE;
}

