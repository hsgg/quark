#ifndef __fifo_h
#define __fifo_h

#include <glib.h>

/* We're using GError's because the GUI will probably need to display the
   error message */
gboolean
fifo_open(const char *filename, GError **error);

void
fifo_close();

#endif
