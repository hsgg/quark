#ifndef __fifo_h
#define __fifo_h

#include <glib.h>
#include <glib-object.h>

G_BEGIN_DECLS

#define QUARKCLIENT_TYPE            (quarkclient_get_type ())
#define QUARKCLIENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), QUARKCLIENT_TYPE, QuarkClient))
#define QUARKCLIENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), QUARKCLIENT_TYPE, QuarkClient))
#define IS_QUARKCLIENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), QUARKCLIENT_TYPE))
#define IS_QUARKCLIENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((obj), QUARKCLIENT_TYPE))

typedef struct _QuarkClient      QuarkClient;
typedef struct _QuarkClientClass QuarkClientClass;

struct _QuarkClient {
    GObject     object;

    gchar      *input_path;
    gchar      *output_path;

    GIOChannel *input;  /* receive data from quark */
    GIOChannel *output; /* send data to quark */
};

struct _QuarkClientClass {
    GObjectClass parent_class;

    void (* closed) (); /* connection to the backend closed */

    void (* playlist_changed) ();
    void (* playlist_position_changed) ();
};

GType quarkclient_get_type ();

QuarkClient *quarkclient_new ();

gboolean quarkclient_open (QuarkClient *qc, GError **error);
void quarkclient_close (QuarkClient *qc);

G_END_DECLS

#endif
